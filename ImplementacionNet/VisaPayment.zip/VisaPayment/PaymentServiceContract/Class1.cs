﻿using System;

namespace PaymentServiceContract
{
    public class Class1
    {
    }
}
