﻿using System;

namespace Entities
{
    public class Class1
    {
    }
}
